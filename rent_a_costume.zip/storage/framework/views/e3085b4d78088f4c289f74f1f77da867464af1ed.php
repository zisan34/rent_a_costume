    <nav class="ct-menuMobile">
        <ul class="ct-menuMobile-navbar">
            <li class="dropdown">
                <a href="<?php echo e(route('home')); ?>"><i class="fa fa-home fa-fw"></i> Home</a>
                
            </li>
            <li class="dropdown">
                <a href="#"><i class="fa fa-building-o fa-fw"></i> Pages</a>
                <ul class="dropdown-menu">
                    <li><a href="about-us.html"><i class="fa fa-angle-right fa-fw"></i> About Us</a></li>
                    
                    <li><a href="pricing.html"><i class="fa fa-angle-right fa-fw"></i> Pricing</a></li>
                    <li><a href="our-services.html"><i class="fa fa-angle-right fa-fw"></i> Our services</a></li>
                   
                    <li><a href="faq.html"><i class="fa fa-angle-right fa-fw"></i> FAQ</a></li>
                </ul>
            </li>
            <li class="dropdown">
               
            </li>
   
          
            <li><a href="contact.html"><i class="fa fa-phone-square fa-fw"></i> Contact</a></li>
        </ul>
    </nav><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/inc/mobile-menu.blade.php ENDPATH**/ ?>