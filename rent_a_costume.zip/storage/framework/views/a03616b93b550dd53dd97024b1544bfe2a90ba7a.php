
        <?php echo $__env->yieldContent('css'); ?>

        <!-- App css -->
        <link href="<?php echo e(URL::asset('backend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" /><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/layouts/head.blade.php ENDPATH**/ ?>