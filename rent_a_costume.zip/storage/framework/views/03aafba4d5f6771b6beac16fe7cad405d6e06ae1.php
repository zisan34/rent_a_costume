========== Left Sidebar Start ========== -->
<div class="left-side-menu">

    <div class="slimscroll-menu">

        <!--- Sidemenu -->
        <div id="sidebar-menu">

            <ul class="metismenu" id="side-menu">

                <li class="menu-title">Navigation</li>

                <li>
                    <a href="<?php echo e(url('admin/adminDashboard')); ?>">
                        <i class="fe-airplay"></i>
                        
                        <span> Dashboards </span>
                    </a>
                    
                </li>

                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-pocket"></i>
                        <span> Apps </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        
                        <li>
                            <a href="<?php echo e(url('admin/apps-calendar')); ?>">Calendar</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('admin/apps-contacts')); ?>">Contacts</a>
                        </li>
                       
                    </ul>
                </li>

              <li>
                    <a href="javascript: void(0);">
                        <i class="fe-users"></i>
                        <span> Products Category and Brands </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        
                        <li>
                            <a href="javascript: void(0);">
                                 <span> Category  </span>
                                 <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                <li><a href="<?php echo e(url('admin/showCat')); ?>">Show all Category</a></li>
                                <li><a href="<?php echo e(url('admin/addCategory')); ?>"">Add Category</a></li>
                                <li><a href="<?php echo e(url('admin/editCategory')); ?>">Edit Category</a></li>
                            </ul>
                        </li>
                        <li>
                            <a href="javascript: void(0);">
                                 <span>  Brands </span>
                                 <span class="menu-arrow"></span>
                            </a>
                            <ul class="nav-second-level" aria-expanded="false">
                                 <li><a href="<?php echo e(url('admin/showBrand')); ?>">Show all Brand</a></li>
                                <li><a href="<?php echo e(url('admin/addBrand')); ?>">Add Brands</a> </li>
                                <li><a href="<?php echo e(url('admin/editBrand')); ?>">Brands</a>  </li>
                            </ul>
                        </li>
                        
                       
                    </ul>
                </li>

                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-shopping-cart"></i>
                        <span> E-Commerce </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        
                        <li>
                            <a href="<?php echo e(url('admin/ecommerce-products')); ?>">Products</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('admin/showComment')); ?>">Product Comment</a>
                        </li>
                       
                        <li>
                            <a href="<?php echo e(url('admin/total_orders')); ?>">Orders</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('admin/total_invoice')); ?>">Invoices</a>
                        </li>
                        
                    </ul>
                </li>

                
                
                <li>
                    <a href="javascript: void(0);">
                        <i class="fe-mail"></i>
                        <span> Email </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <ul class="nav-second-level" aria-expanded="false">
                        
                        <li>
                            <a href="email-compose">Compose Email</a>
                        </li>
                        <li>
                            <a href="<?php echo e(route('email.multiple')); ?>">Multiple Email</a>
                        </li>
                        
                    </ul>
                </li>

              
               

                <li>
                    <a href="<?php echo e(route('userManagement')); ?>">
                        <i class="fe-users"></i>
                        
                        <span>User Management </span>
                    </a>
                </li>



                <li>
                    <a href="<?php echo e(route('admin.faqs')); ?>">
                        <i class="fe-bookmark"></i>
                        
                        <span>FAQs</span>
                    </a>
                </li>


                <li>
                    <a href="<?php echo e(route('siteSettings')); ?>">
                        <i class="fe-settings"></i>
                        
                        <span> Site Settings </span>
                    </a>
                </li>


               

           


              
       
            </ul>

        </div>
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<!-- Left Sidebar End<?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>