<?php $__env->startSection('css'); ?>
        <!-- Plugin css -->
        <link href="<?php echo e(URL::asset('backend/assets/libs/fullcalendar/fullcalendar.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Apps</a></li>
                                            <li class="breadcrumb-item active">Calendar</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Calendar</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 
                        <div class="row">
                            <div class="col-12">
                                <form method="post" action="<?php echo e(route('event.add')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label for="Title"><strong>Title:</strong></label>
                                        <input type="text" class="form-control" name="title">
                                      </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12"></div>
                                        <div class="form-group col-md-12">
                                        <strong> Description(optional): </strong>  
                                        <input class="date form-control"  type="text" id="description" name="description">
                                        </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <strong> Start Date : </strong>  
                                        <input class="date form-control"  type="date" id="startdate" name="startdate">   
                                     </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <strong> End Date : </strong>  
                                        <input class="date form-control"  type="date" id="enddate" name="enddate">   
                                     </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <button type="submit" class="btn btn-success">Add Event</button>
                                      </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-12">
                                <?php echo $calendar->calendar(); ?>

                            </div>
                            <!-- end col-12 -->
                        </div> <!-- end row -->
                        
                    </div> <!-- container -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

        <!-- plugin js -->
        <script src="<?php echo e(URL::asset('backend/assets/libs/moment/moment.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/jquery-ui/jquery-ui.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/fullcalendar/fullcalendar.min.js')); ?>"></script>

        <!-- Calendar init -->
        

        <?php echo $calendar->script(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/apps-calendar.blade.php ENDPATH**/ ?>