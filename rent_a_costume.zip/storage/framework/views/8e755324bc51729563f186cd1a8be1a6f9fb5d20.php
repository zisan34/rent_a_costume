<?php $__env->startSection('css'); ?>
        <!-- Tablesaw css -->
        <link href="<?php echo e(URL::asset('backend/assets/libs/tablesaw/tablesaw.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                         
                        <!-- end page title --> 


                        <div class="row">
                            <div class="col-12">
                                <div class="card-box">

                                    
                                    <table class="tablesaw table mb-0" data-tablesaw-mode="stack">
                                        <thead>
                                        <tr>
                                            <th scope="col"  >Order Batch</th>
                                            <th scope="col" >Product</th>
                                            <th scope="col" >User</th>
                                            <th scope="col" >Price</th>
                                            <th  scope="col">Start Date</th>
                                            <th  scope="col">End Date</th>
                                            <th scope="col"  >At</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($orders): ?>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $product=App\Product::find($order->product_id);
                                                    $user=App\User::find($order->user_id);
                                                ?>
                                                <tr>
                                                    <td><?php echo e($order->order_batch); ?></td>
                                                    <td><?php echo e($product->product_name); ?></td>
                                                    <td><?php echo e($user->email); ?></td>
                                                    <td><?php echo e($product->price); ?></td>
                                                    <td><?php echo e($order->start_date); ?></td>
                                                    <td><?php echo e($order->end_date); ?></td>
                                                    <td><?php echo e($order->created_at); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           <?php endif; ?>
                                       
                                   
                                        </tbody>
                                        <?php echo e($orders->links()); ?>

                                    </table>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->


                     
                        <!-- end row -->


                       
                        <!-- end row -->


                        <!-- end row -->


                      
                        <!-- end row -->


                        <!-- end row -->


                        <!-- end row -->
                        
                    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

        <!-- Tablesaw js -->
        <script src="<?php echo e(URL::asset('assets/libs/tablesaw/tablesaw.min.js')); ?>"></script>

        <!-- Init js -->
        <script src="<?php echo e(URL::asset('assets/js/pages/tablesaw.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/total_order.blade.php ENDPATH**/ ?>