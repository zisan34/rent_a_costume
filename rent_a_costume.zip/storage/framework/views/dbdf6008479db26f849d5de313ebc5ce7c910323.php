<?php $__env->startSection('content'); ?>

<div class="ct-preloader"><div class="ct-preloader-content"></div></div>


    <div id="ct-js-wrapper" class="ct-pageWrapper">
        <!-- navbar + logo menu -->
     

        <div class="ct-contentWrapper">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h4 class="ct-headerBox ct-u-borderBottom ct-u-paddingBottom20 text-left ct-u-paddingTop40">Single Product</h4>
                        <div class="ct-productSection ct-u-paddingBoth50">
                            <div class="row">
                                <div class="col-md-5">
                                    <div class="ct-productGallery ct-js-popupGallery" data-snap-ignore="true">
                                      
                                       
                                            <?php if($image_count>0): ?>
                                            <div class="item">
                                                <a href="<?php echo e(asset('upload/product/'.$image[0]->image)); ?>" class="ct-js-magnificPopupImage"><img src="<?php echo e(asset('upload/product/'.$image[0]->image)); ?>" alt="Product 1"></a>
                                            </div>
                                            <?php endif; ?>
                                       
                                       
                                    </div>
                                    
                                </div>
                                <div class="col-md-7">
                                    <div class="ct-productCustomization">
                                        <h3>Added On: <?php echo e($product->created_at); ?></h3>
                                        <div class="ct-categoryDivider">
                                            <h5><?php echo e($product->product_name); ?></h5>
                                            <button onclick="addto_card('<?php echo e($product->id); ?>')" class="btn btn-sm btn-default">Add to Cart</button>
                                        </div>
                                        <div class="ct-price">
                                           
                                            <span class="ct-u-colorBlack ct-u-size40">$<?php echo e($product->price); ?></span>
                                           
                                        </div>
                                        
                                        <div class="ct-stars">
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star"></i>
                                            <i class="fa fa-star ct-u-colorGrey"></i>
                                            <i class="fa fa-star ct-u-colorGrey"></i>
                                            <div class="ct-reviews">
                                                <a href="#">2 customer reviews</a>
                                            </div>
                                        </div>

                                      
                                           
                                       
                                       
                                            <div class="ct-productSize">
                                                <div class="ct-u-size16 ct-u-paddingBottom10">Last Rent : <?php echo e($product->last_rent); ?></div>
                                               
                                            </div>
                                            <div class="ct-u-size16 ct-u-paddingTop10">Availability:
                                                <?php if($product->availability==1): ?>
                                                    <i class="badge badge-success"><b>Yes</b></i>
                                                <?php else: ?> 
                                                    <i class="badge badge-danger"><b>No</b></i>
                                                <?php endif; ?>
                                            </div>
                                            
                                            <div class="ct-productQuantity">
                                                
                                            </div>
                                            <div class="ct-speedbuy ct-u-paddingBoth20">
                                                <a class="btn btn-default" onclick="addto_card('<?php echo e($product->id); ?>')" role="button"><i class="fa fa-shopping-cart"></i></a>
                                                <div class="ct-or text-uppercase ct-u-paddingBottom20">
                                                    OR
                                                </div>
                                               
                                            </div>
                                      
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div role="tabpanel" class="ct-u-paddingTop20 ct-u-paddingBottom30">
                            <!-- Nav tabs -->
                            <ul class="nav nav-tabs" role="tablist">
                                <li role="presentation" class="active"><a href="#description" aria-controls="description" role="tab" data-toggle="tab">Description</a></li>
                                <li role="presentation"><a href="#specification" aria-controls="specification" role="tab" data-toggle="tab">Product Specification</a></li>
                                
                                <li role="presentation"><a href="#reviews" aria-controls="reviews" role="tab" data-toggle="tab">Customer Reviews</a></li>
                                
                            </ul>
                            <!-- Tab panes -->
                            <div class="tab-content">
                                <div role="tabpanel" class="tab-pane active" id="description">
                                    <div class="adjust-text">
                                        <div class="ct-u-paddingBottom30 ct-u-paddingTop10 ct-panelWidget">
                                            <a href="#" class="pull-left"><i class="fa fa-fw fa-file-text-o"></i> <?php echo e($product->product_name); ?></a>
                                                <span class="pull-right">Adjust Text Size <a href="#" class="plus">+</a><a href="#" class="minus">-</a></span>
                                            <div class="clearfix"></div>
                                        </div>
                                        <p>
                                            <?php echo e($product->description); ?>

                                        </p>
                                       
                                    </div>
                                </div>
                                <div role="tabpanel" class="tab-pane" id="specification">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <table class="table ct-table ct-u-marginBoth20">
                                                <thead>
                                                <tr>
                                                    <th colspan="2">General</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <th>Brand</th>
                                                    <td><?php echo e($brand->brand_name); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Product Code</th>
                                                    <td><?php echo e($product->unique_code); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Last Rent</th>
                                                    <td><?php echo e($product->last_rent); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Unit Time Price</th>
                                                    <td><?php echo e($product->price); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Model Name</th>
                                                    <td><?php echo e($product->product_name); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Added at</th>
                                                    <td><?php echo e($product->created_at); ?></td>
                                                </tr>
                                               
                                                </tbody>
                                            </table>
                                        </div>
                
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <table class="table ct-table ct-u-marginBoth20">
                                                <thead>
                                                <tr>
                                                    <th colspan="2">Rent Features</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <th>Rent frequency</th>
                                                    <td><?php echo e($product->rent_frequency($product->id)); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Quality</th>
                                                    <td>Good</td>
                                                </tr>
                                                <tr>
                                                    <th>Availability</th>
                                                    <td>
                                                         <?php if($product->availability==1): ?>
                                                            <i class="badge badge-success"><b>Yes</b></i>
                                                        <?php else: ?> 
                                                            <i class="badge badge-danger"><b>No</b></i>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                       
                                    </div>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <table class="table ct-table ct-u-marginBoth20">
                                                <thead>
                                                <tr>
                                                    <th colspan="2">Additional Info</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <th>Category</th>
                                                    <td><?php echo e($category->category_name); ?></td>
                                                </tr>
                                                <tr>
                                                    <th>Quantity Total</th>
                                                    <td><?php echo e($product->quantity); ?></td>
                                                </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                              
                                <div role="tabpanel" class="tab-pane" id="reviews">
                                    <div class="ct-reviewImageBox">
                                        <img src="assets/images/demo-content/review-image.jpg" alt="Review Image">
                                    </div>
                                    <div class="ct-ratings">
                                        <div class="ct-ratingsLeft">
                                            <h4>Rating Snapshot</h4>
                                            <div class="ct-stars">
                                                <i class="fa fa-star"><?php echo e($product->averageRate()); ?></i>
                                                
                                                <div class="ct-reviews">
                                                    <a href="#"><?php echo e($product->totalCommentsCount()); ?> customer reviews</a>
                                                </div>
                                            </div>
                                           
                                           
                                        </div>
                                        
                                        <div class="clearfix"></div>
                                        <hr>
                                       
                                    </div>
                                    <div class="clearfix"></div>
                                    <h4 class="ct-fw-600 ct-u-paddingBottom30 ct-u-marginBottom0 ct-u-paddingTop30">2 Reviews</h4>
                                    <?php
                                       $me=Auth::user();
                                        $comments=DB::table('comments')->where('commentable_id',$product->id)
                                                                       ->get();
                                    ?>
                                    <?php if($comments): ?>
                                        <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $com): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php
                                            $u=$com->commented_id;
                                            $u=App\User::find($u);
                                        ?>
                                            <div class="ct-feedback ct-u-paddingTop30">
                                                <span class="pull-left"><?php echo e($product->product_name); ?></span><span></span>
                                                <span class="pull-right"><i class="fa fa-pencil fa-fw"></i>  Posted by: <a href="#" class="author"><?php echo e($u->name); ?></a></span>
                                                <div class="clearfix"></div>
                                                <div class="ct-stars ct-u-paddingBoth10">
                                                    <i class="fa fa-star"></i>
                                                
                                                </div>
                                                <div class="ct-feedbackDescription ct-u-paddingBottom20">
                                                   <?php echo e($com->comment); ?>

                                                </div>
                                                
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                   
                                    <div class="ct-feedback ct-u-paddingTop25">
                                        <div class="row">
                                            <div class="col-md-8">
                                                <?php if(auth()->guard()->check()): ?>
                                                <?php
                                                   
                                                    $tm=Auth::user()->id;
                                                    $checker=App\Order::where('user_id',$tm)->where('product_id',$product->id)->count();
                                                ?>
                                                <h4 class="ct-fw-600 ct-u-paddingBottom20 ct-u-marginBottom0">Help others! Write a review</h4>
                                                <div class="ct-u-size16">All fields are mandatory.</div>
                                                <?php if($checker>0): ?>
                                                <form class="form-horizontal ct-u-paddingTop30" method="POST" action="<?php echo e(url('submit_rating')); ?>">
                                                   <?php echo csrf_field(); ?>
                                                   <input type="hidden" name="pro_id" value="<?php echo e($product->id); ?>">
                                                    <div class="form-group">
                                                        <label for="review" class="col-sm-3 control-label">Your Review:</label>
                                                        <div class="col-sm-9">
                                                            <textarea id="review" name="comment" class="form-control" rows="6"></textarea>
                                                            <span>Please do not include: HTML, references to other retailers, pricing, personal informations, any profane, inflammatory or copyrighted comments, or any copied content.</span>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="name" class="col-sm-3 control-label">Your Rating:</label>
                                                        <div class="col-sm-9">
                                                            <div class="lead">
                                                                <div id="stars-existing" class="starrr" data-rating='4'>
                                                                    <input type="number" name="rating" class="form-control">
                                                                </div>
                                                            </div>
                                                           
                                                        </div>
                                                    </div>
                                                   
                                                    
                                                    <div class="form-group ct-u-paddingTop30">
                                                        <input class="btn btn-default " type="submit" value="Submit">
                                                       
                                                    </div>
                                                </form>
                                                <?php endif; ?>
                                                <?php endif; ?>
                                            </div>
                                            <div class="col-md-4">
                                                <div class="widget">
                                                    <div class="widget-inner">
                                                        <div class="ct-widgetReview">
                                                            <h3>What makes a good review</h3>
                                                            <ul class="list-unstyled">
                                                                <li>
                                                                    <div><i class="fa fa-fw fa-long-arrow-right"></i> Have you used this product?</div>
                                                                    <p>It's always better to review a product you have personally experienced.</p>
                                                                </li>
                                                                <li>
                                                                    <div><i class="fa fa-fw fa-long-arrow-right"></i> Educate your readers</div>
                                                                    <p>Provide a relevant, unbiased overview of the product. Readers are interested in the pros and the cons of the product.</p>
                                                                </li>
                                                                <li>
                                                                    <div><i class="fa fa-fw fa-long-arrow-right"></i> Be yourself, be informative</div>
                                                                    <p>Let your personality shine through, but it's equally important to provide facts to back up your opinion.</p>
                                                                </li>
                                                                <li>
                                                                    <div><i class="fa fa-fw fa-long-arrow-right"></i> Stay concise</div>
                                                                    <p>Be creative but also remember to stay on topic. A catchy title gets attention!</p>
                                                                </li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                               
                               
                            </div>
                        </div>

                    </div>
                </div>
                <h4 class="ct-headerBox text-left ct-u-borderBottom3 ct-u-paddingBottom15 ct-u-paddingTop55">Recommendations For You </h4>
                <div class="ct-u-paddingBottom50 ct-u-paddingTop35">
                    <div class="ct-js-owl owl-carousel ct-productCarousel ct-productCarousel--arrowsTopRight" data-single="false" data-pagination="false" data-navigation="true" data-items="4" data-snap-ignore="true">
                        <?php if($related_products): ?>
                          <?php $__currentLoopData = $related_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recommend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php
                              $image=$recommend->img($recommend->id);
                          ?>
                            <div class="item">
                                <div class="ct-productShop ct-productShop--zoom">
                                    <div class="ct-productShop-category">
                                        <span class="ct-productShop-h5"><?php echo e($recommend->product_name); ?></span>
                                        <div class="clearfix"></div>
                                        <?php if($recommend->img_count($recommend->id)>0): ?>
                                        <img class="ct-js-zoomImage" src="<?php echo e(asset('upload/product/'.$image[0]->image)); ?>" data-zoom-image="<?php echo e(asset('upload/product/'.$image[0]->image)); ?>" alt="">
                                        <?php endif; ?>
                                    </div>
                                    <div class="ct-productShop-content">
                                        <div class="ct-productShop-content-description">
                                            <a href="single-product.html">
                                                <h3><?php echo e($recommend->description); ?></h3>
                                                <span> $<?php echo e($recommend->price); ?></span>
                                            </a>
                                            <span class="ct-productShop-shopCart">
                                                <a class="btn btn-default" href="#" onclick="addto_card('<?php echo e($recommend->id); ?>')" role="button"><i class="fa fa-shopping-cart fa-fw"></i></a>
                                                <a class="btn btn-default btn-hidden" href="single-product.html" role="button"><i class="fa fa-chain fa-fw"></i></a>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                      
                    </div>
                      <?php echo e($related_products->links()); ?>

                </div>
            </div>

            <!-- No padding here for ct-prefooter - disabled ct-u-paddingTop60 -->

            <!-- PreFOOTER -->
          
        </div>

        <!-- FOOTER -->
    
    </div>
    <script>
function addto_card(id){
    event.preventDefault();
    $.ajax({
        type:'get',
        url:'<?php echo e(url('addto_card')); ?>',
        data:{'id':id},
        success:function(res){
            console.log(res);
            if(res=='success'){
                alert('cart Added');
            }else{
                alert("Cart not Added, please try again later!");
            }
        }
    })
}
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/customer/single_product.blade.php ENDPATH**/ ?>