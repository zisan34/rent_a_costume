<?php $__env->startSection('content'); ?>

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Extras</a></li>
                                            <li class="breadcrumb-item active">FAQs</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">FAQs</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title -->
                        
                        
                        <!-- end row -->

    
                        <!-- end page title --> 

                        <!-- Right Sidebar -->
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="mt-4">
                                    <form method="post" action="<?php echo e(route('faq.add')); ?>">
                                        <?php echo csrf_field(); ?>

                                        <div class="form-group">
                                            <select class="form-control" name="faq_category" placeholder="Subject">
                                                <option disabled selected>--Select Category--</option>
                                                <?php $__currentLoopData = $faqCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($faqCategory->id); ?>"><?php echo e($faqCategory->title); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="alert-danger"><?php echo e($errors->first('faq_category')); ?></div>

                                        </div>

                                        <div class="form-group">
                                            <input type="text" class="form-control" name="question" placeholder="Question">
                                            <div class="alert-danger"><?php echo e($errors->first('question')); ?></div>

                                        </div>

                                        <div class="form-group">
                                            <input type="text" class="form-control" name="answer" placeholder="Answer">
                                            <div class="alert-danger"><?php echo e($errors->first('answer')); ?></div>

                                        </div>

                                        <div class="form-group m-b-0">
                                            <div class="text-right">
                                                
                                                <input type="submit" value="Add new FAQ" class="btn btn-primary waves-effect waves-light">

                                            </div>
                                        </div>

                                    </form>
                                </div> <!-- end card-->
                            </div>
                        </div><!-- End row -->
                        


                        <div class="row pt-5">
                            <?php $__currentLoopData = $faqCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-lg-5 offset-lg-1">
                                <!-- Question/Answer -->
                                <h2>Categoty:<?php echo e($faqCategory->title); ?></h2>
                                <?php $__currentLoopData = $faqCategory->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div>
                                    <div class="faq-question-q-box">Q.</div>
                                    <h4 class="faq-question" data-wow-delay=".1s"><a href="<?php echo e(route('faq.show',['id'=>$faq->id])); ?>"><?php echo e($faq->question); ?></a></h4>
                                    <p class="faq-answer mb-4"><?php echo e($faq->answer); ?></p>
                                </div> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>       
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <!--/col-md-5 -->
        

                            <!--/col-md-5-->
                        </div>
                        <!-- end row -->

                        
                    </div> <!-- container -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/faqs.blade.php ENDPATH**/ ?>