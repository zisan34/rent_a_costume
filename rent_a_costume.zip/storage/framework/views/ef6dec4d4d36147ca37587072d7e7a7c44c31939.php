<?php $__env->startSection('content'); ?>

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                       <?php echo $__env->make('admin.layouts.bradcum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <div class="row">
                            <div class="col-md-6 col-xl-3">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded bg-soft-primary">
                                                <i class="dripicons-wallet font-24 avatar-title text-primary"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark mt-1"><?php echo e(count($total_user)); ?></h3>
                                                <p class="text-muted mb-1 text-truncate">Total User</p>
                                            </div>
                                        </div>
                                    </div> <!-- end row-->
                                </div> <!-- end widget-rounded-circle-->
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded bg-soft-success">
                                                <i class="dripicons-basket font-24 avatar-title text-success"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo e(count($total_order)); ?></span></h3>
                                                <p class="text-muted mb-1 text-truncate">Total Order</p>
                                            </div>
                                        </div>
                                    </div> <!-- end row-->
                                </div> <!-- end widget-rounded-circle-->
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded bg-soft-info">
                                                <i class="dripicons-store font-24 avatar-title text-info"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark mt-1"><span data-plugin="counterup"><?php echo e(count($total_product)); ?></span></h3>
                                                <p class="text-muted mb-1 text-truncate">Stores Total</p>
                                            </div>
                                        </div>
                                    </div> <!-- end row-->
                                </div> <!-- end widget-rounded-circle-->
                            </div> <!-- end col-->

                            <div class="col-md-6 col-xl-3">
                                <div class="widget-rounded-circle card-box">
                                    <div class="row">
                                        <div class="col-6">
                                            <div class="avatar-lg rounded bg-soft-warning">
                                                <i class="dripicons-user-group font-24 avatar-title text-warning"></i>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="text-right">
                                                <h3 class="text-dark mt-1"><span data-plugin="counterup">$<?php echo e($total_money); ?></span></h3>
                                                <p class="text-muted mb-1 text-truncate">Invoice Total</p>
                                            </div>
                                        </div>
                                    </div> <!-- end row-->
                                </div> <!-- end widget-rounded-circle-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row -->


             
                        <!-- end row -->


                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card-box">
                                    <h4 class="header-title mb-3">Product History</h4>

                                    <div class="table-responsive">
                                        <table class="table table-centered table-hover mb-0">
                                            <thead>
                                                <tr>
                                                    <th class="border-top-0">Name</th>
                                                    <th class="border-top-0">Batch</th>
                                                    <th class="border-top-0">Last Rent</th>
                                                    <th class="border-top-0">Price</th>
                                                    <th class="border-top-0"> Rent rate(rent/day)</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if($products): ?>
                                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($pro->product_name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($pro->unique_code); ?>

                                                    </td>
                                                    <td><?php echo e($pro->last_rent); ?></td>
                                                    <td>$<?php echo e($pro->price); ?></td>
                                                    <td>
                                                        <?php
                                                            $created=Carbon\Carbon::parse($pro->created_at)->format('Y-m-d');
                                                            $diff=$today->diffInDays($pro->created_at);;
                                                           // echo $diff;
                                                           $order_gain=App\Order::where('product_id',$pro->id)->count();
                                                           $val=$order_gain/$diff;
                                                        ?>
                                                            <?php echo e($val); ?> %
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                              
                                            
                                            </tbody>
                                        </table>
                                        <?php echo e($products->links()); ?>

                                    </div> <!-- end table-responsive -->

                                </div> <!-- end card-box-->
                            </div> <!-- end col-->
                        </div>
                        <!-- end row-->
                        
                    </div> <!-- container -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

        <!--Morris Chart-->
        <script src="<?php echo e(URL::asset('backend/assets/libs/morris-js/morris-js.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/raphael/raphael.min.js')); ?>"></script>

        <!-- Dashboard init js -->
        <script src="<?php echo e(URL::asset('backend/assets/js/pages/ecommerce-dashboard.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/ecommerce-dashboard.blade.php ENDPATH**/ ?>