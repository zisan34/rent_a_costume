 <div class="row">
    <div class="col-12">
        <div class="page-title-box">
            <div class="page-title-right">
                <ol class="breadcrumb m-0">
                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e(env('APP_NAME')); ?></a></li>
                    <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($site_title); ?></a></li>
                   
                </ol>
            </div>
           
        </div>
    </div>
</div> <?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/layouts/bradcum.blade.php ENDPATH**/ ?>