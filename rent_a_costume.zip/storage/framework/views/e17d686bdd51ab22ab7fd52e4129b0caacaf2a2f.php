<?php $__env->startSection('content'); ?>
    
<div class="container">
    <div class="panel-group ct-u-marginBottom40" id="accordion" role="tablist" aria-multiselectable="true">        
        <?php
            $i=0;
        ?>
        <?php $__currentLoopData = $faqCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faqCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="panel panel-default">
            <div class="panel-heading" role="tab" id="headingOne">
                <h4 class="panel-title">
                    <a data-toggle="collapse" data-parent="#accordion" href="#collapse<?php echo e($i); ?>" aria-expanded="<?php if($i==0): ?>true <?php else: ?> false <?php endif; ?>" aria-controls="collapseOne" class="<?php if($i!=0): ?> collapsed <?php endif; ?>">
                        <i class="fa fa-circle ct-u-size4 ct-u-verticalMiddle ct-u-paddingRight5"></i> <?php echo e($faqCategory->title); ?>

                    </a>
                </h4>
            </div>
            <div id="collapse<?php echo e($i); ?>" class="panel-collapse collapse <?php if($i==0): ?> in <?php endif; ?>" role="tabpanel" aria-labelledby="headingOne" aria-expanded="true" style="">
                <?php $__currentLoopData = $faqCategory->faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $faq): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-body">
                    <ul>
                    <li>
                        <h4><?php echo e($faq->question); ?></h4>
                    </li>
                    <p><?php echo e($faq->answer); ?></p>
                    </ul>
                    
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <?php
            $i++;
        ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/faqs.blade.php ENDPATH**/ ?>