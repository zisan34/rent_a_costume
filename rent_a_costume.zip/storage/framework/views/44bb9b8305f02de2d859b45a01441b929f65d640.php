<?php $__env->startSection('css'); ?>
        <!-- Tablesaw css -->
        <link href="<?php echo e(URL::asset('backend/assets/libs/tablesaw/tablesaw.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                         
                        <!-- end page title --> 


                        <div class="row">
                            <div class="col-12">
                                <div class="card-box">

                                    
                                    <table class="tablesaw table mb-0" data-tablesaw-mode="stack">
                                        <thead>
                                        <tr>
                                            <th scope="col"  >Invoice No</th>
                                            <th scope="col"  >Title</th>
                                            <th scope="col" >Transection ID.</th>
                                            <th scope="col" >Payer Email</th>
                                            <th scope="col" >Payer Name</th>
                                            <th  scope="col">Invoice ID.</th>
                                            <th  scope="col">Price</th>
                                           
                                            <th scope="col"  >At</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($invoices): ?>
                                                <?php $__currentLoopData = $invoices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invoice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               
                                                <tr>
                                                    <td><?php echo e($invoice->id); ?></td>
                                                    <td><?php echo e($invoice->title); ?></td>
                                                    <td><?php echo e($invoice->transection_id); ?></td>
                                                    <td><?php echo e($invoice->payer_email); ?></td>
                                                    <td><?php echo e($invoice->payer_name); ?></td>
                                                    <td><?php echo e($invoice->invoice_id); ?></td>
                                                    <td><?php echo e($invoice->price); ?></td>
                                                    <td><?php echo e($invoice->created_at); ?></td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           <?php endif; ?>
                                       
                                   
                                        </tbody>
                                        <?php echo e($invoices->links()); ?>

                                    </table>
                                </div> <!-- end card-box-->
                            </div> <!-- end col -->
                        </div>
                       
                        
                    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

        <!-- Tablesaw js -->
        <script src="<?php echo e(URL::asset('backend/assets/libs/tablesaw/tablesaw.min.js')); ?>"></script>

        <!-- Init js -->
        <script src="<?php echo e(URL::asset('backend/assets/js/pages/tablesaw.init.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/total_invoice.blade.php ENDPATH**/ ?>