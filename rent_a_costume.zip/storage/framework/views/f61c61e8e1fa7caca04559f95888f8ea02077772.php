<?php $__env->startSection('content'); ?>
    
<div class="ct-preloader"><div class="ct-preloader-content"></div></div>
 

    <div id="ct-js-wrapper" class="ct-pageWrapper">
       
         <form action="<?php echo e(url('edit_my_profile')); ?>" method="POST" enctype="multipart/form-data">
<?php echo csrf_field(); ?>
            <div class="ct-contentWrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-md-8">
                            <h4 class="ct-headerBox ct-u-borderBottom ct-u-paddingBottom20 text-left ct-u-paddingTop50">My Account</h4>
                           
                            <div class="card">
                                <?php if($user_image): ?>
                                <img src="<?php echo e(asset('upload/user/'.$user_image->image)); ?>" alt="">
                                <h6>Change Image</h6>
                                    <input type="file" name="image" class="form-control">
                                <?php else: ?> 
                                <img src="<?php echo e(asset('upload/user/default.png')); ?>" alt="">
                                <h6>Change Image</h6>
                                    <input type="file" name="image" class="form-control">
                                <?php endif; ?>
                            </div>
                            <div class="ct-u-size16 ct-u-paddingBottom20 ct-u-paddingTop30">Hello
                                <input type="text" class="form-control" name="name" value="<?php echo e($me->name); ?>"> 

                                <input type="text" class="form-control" disabled value="<?php echo e($me->email); ?>"> 
                            </div>
                            <div class="ct-u-size16 ct-u-paddingBottom30">
                                <label for="">Address</label>
                                <input type="text" class="form-control" disabled name="ciry" value="<?php echo e($city->city); ?>">
                                <br>
                                <input type="text" class="form-control" disabled name="country" value="<?php echo e($country->country); ?>">
                            </div>

                            <div class="ct-accountBookmark ct-u-paddingBottom30">
                                <h5 class="ct-u-size18 ct-u-colorLightGrey ct-u-paddingBottom10">Status</h5>
                                <div class="ct-u-size16">
                                    <?php if($me->status==1): ?>
                                      
                                        <i class="badge badge-success">Active</i>
                                    <?php else: ?> 
                                       <i class="badge badge-danger">Inactive</i>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="ct-accountBookmark ct-u-paddingBottom30">
                               
                                <div class="ct-u-size16">Phone</div>
                                <div class="ct-u-paddingTop10">
                                   <input type="number" class="form-control" class="" name="phone" value="<?php echo e($me->phone); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <input type="submit" class="btn btn-success">
                            </div>

                           
                            
                        </div>
                 
                    </div>
                </div>

                <!-- PreFOOTER -->


            <!-- FOOTER -->

        </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/myprofile.blade.php ENDPATH**/ ?>