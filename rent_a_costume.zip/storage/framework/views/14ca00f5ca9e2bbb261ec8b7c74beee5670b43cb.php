<?php $__env->startSection('css'); ?>
        <link href="<?php echo e(URL::asset('backend/assets/libs/dropzone/dropzone.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/libs/dropify/dropify.min.css')); ?>" rel="stylesheet" type="text/css" />

        <!-- App css -->
        <link href="<?php echo e(URL::asset('backend/assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- Plugins css -->

        <link href="<?php echo e(URL::asset('backend/assets/libs/jquery-nice-select/jquery-nice-select.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/libs/switchery/switchery.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/libs/multiselect/multiselect.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/libs/select2/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/libs/bootstrap-select/bootstrap-select.min.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('backend/assets/libs/bootstrap-touchspin/bootstrap-touchspin.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <!-- Start Content-->
<div class="container-fluid">
    
    <!-- start page title -->
    <?php echo $__env->make('admin.layouts.bradcum', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>   
    <!-- end page title --> 

    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    

                    <div class="row">
                        <div class="col-lg-12">
                            <table class="table">
                                <thead>
                                    <th>Product Code</th>
                                    <th>Product Name</th>
                                    <th>Product Price</th>
                                </thead>
                                <tbody>
                                    <?php if($products): ?>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($pro->unique_code); ?>

                                            </td>
                                            <td>
                                                <?php echo e($pro->product_name); ?>

                                            </td>
                                            <td>
                                                <?php echo e($pro->price); ?>

                                            </td>
                                        </tr>
                                        <?php
                                            $com_pro=DB::table('comments')->where('commentable_id',$pro->id)->get();
                                        ?>
                                        <?php if($com_pro): ?>
                                        <table class="table">
                                            <thead>
                                                <th></th>
                                                <th></th>
                                                <th>Commentator</th>
                                                <th>Rating</th>
                                                <th>Comment</th>
                                                <th>Time</th>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $com_pro; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php
                                                    $com_user=App\User::find($cp->commented_id);
                                                ?>
                                                    <tr>
                                                        <td></td>
                                                        <td></td>
                                                        <td>
                                                            <?php echo e($com_user->name); ?>

                                                            <i><?php echo e($com_user->email); ?></i>
                                                        </td>
                                                        <td>
                                                            <?php echo e($cp->rate); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($cp->comment); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($cp->created_at); ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                        <br>
                                        <br>
                                        <hr>
                                           
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                                <?php echo e($products->links()); ?>

                            </table>
                        </div> <!-- end col -->

                        
                    </div>
                    <!-- end row-->

                </div> <!-- end card-body -->
            </div> <!-- end card -->
        </div><!-- end col -->
    </div>
    <!-- end row -->

    
</div> <!-- container -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

        <!-- Plugins js -->
        <script src="<?php echo e(URL::asset('backend/assets/libs/dropzone/dropzone.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/dropify/dropify.min.js')); ?>"></script>

        <!-- Init js-->
        <script src="<?php echo e(URL::asset('backend/assets/js/pages/form-fileuploads.init.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/jquery-nice-select/jquery-nice-select.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/switchery/switchery.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/multiselect/multiselect.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/select2/select2.min.js')); ?>"></script>
        
        <script src="<?php echo e(URL::asset('backend/assets/libs/autocomplete/autocomplete.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/bootstrap-select/bootstrap-select.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/bootstrap-touchspin/bootstrap-touchspin.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/bootstrap-maxlength/bootstrap-maxlength.min.js')); ?>"></script>

        <!-- Init js-->
        <script src="<?php echo e(URL::asset('backend/assets/js/pages/form-advanced.init.js')); ?>"></script>
        
         <script>
        function getbrand(cat_id){
            console.log(cat_id);
            $.ajax({
                type:'get',
                data:{'id':cat_id},
                url:'<?php echo e(url('admin/getBrand')); ?>',
                contentType: "text/html",
                 crossDomain:'true',
                success:function(res){
                    console.log(res);
                    $('#brand_get').html(res);
                }
            })
        }
        </script>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/product/showcomment.blade.php ENDPATH**/ ?>