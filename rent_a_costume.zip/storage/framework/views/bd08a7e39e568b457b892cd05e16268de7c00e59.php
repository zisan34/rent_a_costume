<?php $__env->startSection('css'); ?>
        <!-- Plugin css -->
        <link href="<?php echo e(URL::asset('backend/assets/libs/fullcalendar/fullcalendar.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- Summernote css -->
        <link href="<?php echo e(URL::asset('backend/assets/libs/summernote/summernote.min.css')); ?>" rel="stylesheet" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <h4 class="page-title">Site Settings</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 
                        <div class="row">
                            <div class="col-12">
                              <?php echo $__env->make('inc.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <form method="post" action="<?php echo e(route('siteSettings.update')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Website Name:</strong></label>
                                        <input type="text" class="form-control" name="w_name" value="<?php if(isset($settings->w_name)): ?><?php echo e($settings->w_name); ?><?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12"></div>
                                        <div class="form-group col-md-12">
                                        <strong>Website Email:</strong>  
                                        <input class="date form-control"  type="text" name="w_email"  value="<?php if(isset($settings->w_email)): ?><?php echo e($settings->w_email); ?><?php endif; ?>">
                                        </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Website Address:</strong></label>
                                        <input type="text" class="form-control" name="w_address" value="<?php if(isset($settings->w_address)): ?><?php echo e($settings->w_address); ?><?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Website Phone:</strong></label>
                                        <input type="text" class="form-control" name="w_phone" value="<?php if(isset($settings->w_phone)): ?><?php echo e($settings->w_phone); ?><?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Facebook Link:</strong></label>
                                        <input type="url" class="form-control" name="w_facebook" value="<?php if(isset($settings->w_facebook)): ?><?php echo e($settings->w_facebook); ?><?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Youtube Link:</strong></label>
                                        <input type="url" class="form-control" name="w_youtube" value="<?php if(isset($settings->w_youtube)): ?><?php echo e($settings->w_youtube); ?><?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Twitter Link:</strong></label>
                                        <input type="url" class="form-control" name="w_twitter" value="<?php if(isset($settings->w_twitter)): ?><?php echo e($settings->w_twitter); ?><?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Website Copyright:</strong></label>
                                        <input type="text" class="form-control" name="copyright" value="<?php if(isset($settings->copyright)): ?><?php echo e($settings->copyright); ?><?php endif; ?>">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Website Logo:</strong></label>
                                        <?php if(isset($settings->w_logo)): ?><img src="<?php echo e(asset($settings->w_logo)); ?>" height="20px"><?php endif; ?>
                                        <input type="file" name="w_logo" placeholder="choose new logo">
                                      </div>
                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <label><strong>Website Image:</strong></label>
                                        <?php if(isset($settings->w_image)): ?><img src="<?php echo e(asset($settings->w_image)); ?>" height="20px"><?php endif; ?>
                                        <input type="file" name="w_image">
                                      </div>
                                    </div>
                                    <div class="form-group">
                                        <label><strong>About Us:</strong></label>
                                        <textarea class="form-control summernote" id="summernote" name="w_about"  overlay="auto"><?php echo $settings->w_about; ?></textarea>
                                        <div class="alert-danger"><?php echo e($errors->first('about')); ?></div>

                                    </div>
                                    <div class="form-group">
                                        <label><strong>Our Mission:</strong></label>
                                        <textarea class="form-control summernote" id="summernote" name="w_mission"  overlay="auto"><?php echo $settings->w_about; ?></textarea>
                                        <div class="alert-danger"><?php echo e($errors->first('mission')); ?></div>

                                    </div>
                                    <div class="row">
                                      <div class="col-md-12"></div>
                                      <div class="form-group col-md-12">
                                        <button type="submit" class="btn btn-success">Update Settings</button>
                                      </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                    </div> <!-- container -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

        <!-- plugin js -->
        <script src="<?php echo e(URL::asset('backend/assets/libs/moment/moment.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('backend/assets/libs/jquery-ui/jquery-ui.min.js')); ?>"></script>


        <!--Summernote js-->
        <script src="<?php echo e(URL::asset('backend/assets/libs/summernote/summernote.min.js')); ?>"></script>

        <script>
            jQuery(document).ready(function(){
                $('.summernote').summernote({
                    placeholder: 'Write your message here.',
                    height: 200,                 // set editor height
                    minHeight: null,             // set minimum height of editor
                    maxHeight: null,             // set maximum height of editor
                    focus: false ,                // set focus to editable area after initializing summernote
                      toolbar: [
                          ['style', ['style']],
                          ['font', ['bold', 'underline', 'clear']],
                          ['fontname', ['fontname']],
                          ['fontsize', ['fontsize']],
                          ['color', ['color']],
                          ['para', ['ul', 'ol', 'paragraph']],
                          ['table', ['table']],
                          ['insert', ['link', 'picture']],
                          ['view', ['fullscreen', 'help']]
                    ]
                });
            });
        </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/site-settings.blade.php ENDPATH**/ ?>