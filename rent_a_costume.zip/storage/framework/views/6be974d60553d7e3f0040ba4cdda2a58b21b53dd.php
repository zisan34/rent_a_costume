<?php $__env->startSection('css'); ?>
        <!-- Custom box css -->
        <link href="<?php echo e(URL::asset('backend/assets/libs/custombox/custombox.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

                    <!-- Start Content-->
                    <div class="container-fluid">
                        
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box">
                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">UBold</a></li>
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">CRM</a></li>
                                            <li class="breadcrumb-item active">Contacts</li>
                                        </ol>
                                    </div>
                                    <h4 class="page-title">Contacts</h4>
                                </div>
                            </div>
                        </div>     
                        <!-- end page title --> 


                        <div class="row">
                            <div class="col-xl-12">
                                <div class="card">
                                    <div class="card-body">                
                                        <div class="table-responsive">
                                            <table class="table table-centered table-hover mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>Name</th>
                                                        <th>Phone</th>
                                                        <th>Email</th>
                                                        <th>Country</th>
                                                        <th>City</th>
                                                        <th>Gender</th>
                                                        <th>Status</th>
                                                        <th>IP</th>
                                                        <th>URL</th>
                                                        <th style="width: 82px;">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="table-user">
                                                            <img src="<?php echo e(asset('$user->image')); ?>" alt="table-user" class="mr-2 rounded-circle">
                                                            <a href="javascript:void(0);" class="text-body font-weight-semibold"><?php echo e($user->name); ?></a>
                                                        </td>
                                                        <td>
                                                            <?php echo e($user->phone); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($user->email); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($user->country->country); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($user->city->city); ?>

                                                        </td>
                                                        <td>
                                                            <?php echo e($user->gender); ?>

                                                        </td>
                                                        <td>
                                                            <?php if($user->status): ?>
                                                            Active
                                                            <?php else: ?>
                                                            Disabled
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if(isset($user->userTraffic)): ?>
                                                            <?php echo e($user->userTraffic->user_ip); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <?php if(isset($user->userTraffic)): ?> 
                                                            <?php echo e($user->userTraffic->url); ?>

                                                            <?php endif; ?>
                                                        </td>
                                                        <td>                                                        
                                                            <?php if($user->status): ?>
                                                            <a href="<?php echo e(route('user.disable',['id'=>encrypt($user->id)])); ?>" class="btn btn-sm btn-danger">Disable</a>
                                                            <?php else: ?>
                                                            <a href="<?php echo e(route('user.enable',['id'=>encrypt($user->id)])); ?>" class="btn btn-sm btn-success">Enable</a>
                                                            <?php endif; ?>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    
                                                </tbody>
                                            </table>
                                        </div>

                                        

                                    </div> <!-- end card-body-->
                                </div> <!-- end card-->
                            </div> <!-- end col -->
                        </div>
                        <!-- end row -->
                        
                    </div> <!-- container -->




<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

        <!-- Modal-Effect -->
        <script src="<?php echo e(URL::asset('backend/assets/libs/custombox/custombox.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/admin/user-management.blade.php ENDPATH**/ ?>