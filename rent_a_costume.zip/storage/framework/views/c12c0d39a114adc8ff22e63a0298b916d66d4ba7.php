        <!-- TOPBAR -->
        <?php
          
            $myCartCollection =0;
            $myCartSubtotal =0;
            $mycartTotalQuantity =0;
            $myTotal =0;
            if(!Cart::isEmpty()){
                $myCartCollection = Cart::getContent()->toArray();
                $myCartSubtotal = Cart::getSubTotal();;
                $mycartTotalQuantity = Cart::getTotalQuantity();
                $myTotal = Cart::getTotal();
            }
             $ma=0;
           // Cart::clear();
          //  print_r($myCartCollection);
        ?>
        <div class="ct-topBar">
            <div class="container">
                <div class="ct-topBar-navigation pull-left">
                    <ul class="list-unstyled">
                        <li><i class="fa fa-fw fa-phone"></i> Call us: (012) 345-6789</li>
                        <?php if(auth()->guard()->guest()): ?>
                        <li><a href="<?php echo e(route('login')); ?>"><i class="fa fa-fw fa-user"></i> Login</a></li>
                        <li><a href="<?php echo e(route('register')); ?>"><i class="fa fa-fw fa-pencil"></i> Create an account</a></li>
                        <?php else: ?>
                        <li><a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();"><i class="fa fa-fw fa-user"></i> Logout</a></li>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>

                            <?php if(auth()->guard()->check()): ?>
                            <?php if(auth()->user()->is_super_admin): ?>
                            
                            <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>


                    </ul>
                </div>

                
                <div class="pull-right">
                     
                    <div class="ct-topBar-basket">
                        <a href="my-cart.html"><span class="ct-topBar-basket-cart"><i class="fa fa-fw fa-shopping-cart"></i> Cart: </span><span class="ct-topBar-basket-quantity"><?php echo e($mycartTotalQuantity); ?> item(s)</span><span class="ct-topBar-basket-price"> - $<?php echo e($myTotal); ?></span></a>
                        <div class="ct-topBar-basket-info">
                            <?php if(is_array($myCartCollection)): ?>
                                <?php $__currentLoopData = $myCartCollection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myCartCollection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                            // print_r($myCartCollection['id']);
                            //  exit();
                                $cart_product=App\Product::find($myCartCollection['id']);
                                $cart_img=$cart_product->img($cart_product->id);
                               
                                ?>
                                    <div class="ct-cartItem">
                                        <a  href="<?php echo e(url('single_product/'.urlencode($cart_product->id))); ?>">
                                            <div class="ct-cartItem-image pull-left">
                                                <?php if($cart_product->img_count($cart_product->id)>0): ?>
                                                <img src="<?php echo e(asset('upload/product/'.$cart_img[0]->image)); ?>" alt="">
                                                <?php endif; ?>
                                            </div>
                                            <div class="ct-cartItem-title" style="height:60px;width:70px;overflow:hidden">
                                                <?php echo e($cart_product->description); ?>

                                            </div>
                                            <div class="ct-cartItem-price">
                                                $<?php echo e($cart_product->price); ?>

                                            </div>
                                            <div class="clearfix"></div>
                                        </a>
                                    </div>
                                   <?php
                                       $ma++;
                                      
                                       if($ma>1){break;}
                                   ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                           <?php if($mycartTotalQuantity>2): ?>
                           <div>
                               <h5>More.............</h5>
                           </div>
                           <?php endif; ?>
                            <div class="clearfix"></div>
                            <div class="ct-cartSubtotal">
                                <div class="pull-left ct-fw-600">Subtotal: $<?php echo e($myCartSubtotal); ?></div>
                             
                                <div class="clearfix"></div>
                            </div>
                            <div class="ct-cartGoNext text-uppercase ct-u-paddingBoth20">
                                <a class="btn btn-default ct-u-width-49pc" href="<?php echo e(url('mycart')); ?>" role="button">View Cart <i class="fa fa-angle-double-right fa-fw"></i></a>
                                
                            </div>
                        </div>
                    </div>
                   
                   
                </div>
            </div>
        </div><?php /**PATH C:\xampp\htdocs\rent_dress\rent_a_costume\resources\views/inc/topbar.blade.php ENDPATH**/ ?>